/* 

TiendaDepartamental
Descripción: Calcula las ventas de la tienda

Fecha:24-Nov-2020
Versión: 1|
@author López Hernández Lissete
@author Perez Priego Mario Daniel
 */
package Practica;


public class TiendaDepartamental {

    private String nomTienda;
    private String producto;
    private int cantidadVendida;
    public float precioProducto;

    //Constructor: recibe el nombre de la tienda y el producto que vende.
    public TiendaDepartamental(String nomTienda, String producto) {
        this.nomTienda = nomTienda;
        this.producto = producto;
    }

  
//Metodo ventas: calcula el dinero obtenido por la tienda departamental por motivo de ventas, multiplicando el precio por la cantidad de productos vendidos.
    //Recibe: precio del producto y cantidad vendida. Regresa el dinero obtenido por motivo de ventas en un tipo de dtao float. 
    public float ventas(float precio, int cantidad) {
        cantidadVendida = cantidad;
        precioProducto = precio;
        return cantidadVendida * precioProducto;
    }

}
