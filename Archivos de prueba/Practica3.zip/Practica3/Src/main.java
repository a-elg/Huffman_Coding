/* 

Main
Descripción: El programa realiza las siguientes funciones para cada comercio dentro de un centro comercial:
Tienda departamental: Calcula las ventas de la tienda
Estacionamiento: Da el acceso al numero de carros maximo permitido por el espacio diponible y tambien se encarga de la salida de los mismos.
Restaurante: agrega comensales (de uno en uno), calcula la cuenta a pagar,  y obtiene el numero de comensales en el restaurante. 
Centro comercial: A través del centro comercial se debe accesar a los comercios previamente mencionados.

Fecha:24-Nov-2020
Versión: 1|
@author López Hernández Lissete
@author Perez Priego Mario Daniel
 */
package Practica;

import java.util.Scanner;

public class main {
// Main., se ingresan los datos e imprime los resultados

    public static void main(String[] args) {
        try {
            //Se inicializan los objetos carro y tienda los cuales fueron creados en "CentroComercial" debido a su relacion de composicion. El objeto restaurant es creado en el presente archivo "Main" debido a su relación de agregación .
            Estacionamiento carro = null;
            TiendaDepartamental tienda = null;
            Restaurante restaurant = new Restaurante("Isis", "Enchiladas suizas");
            String domicilio = "Cementerio 13, tumba 22";
            double superficie = 1000;
            String nombre = "Vampiro negro  ";

            //Constructor CentroComercial
            CentroComercial centro = new CentroComercial(domicilio, superficie, nombre, restaurant, tienda, carro);

            //Estacionamiento 
            int numcarros, carroOut;
            int cantidadProductos;
            float precioProducto;

            Scanner consola = new Scanner(System.in);
            //metodo:Ingresar carro, recibe el numero de carros a ingresar al estacionamiento, para darle acceso.
            System.out.println("Carros en el estacionamiento:" + centro.getEstacionamiento().getNumCarros());
            System.out.println("Escribe el numero de carros a ingresar");
            numcarros = consola.nextInt();
            centro.getEstacionamiento().ingresarCarro(numcarros);
            System.out.println("Carros en el estacionamiento:" + centro.getEstacionamiento().getNumCarros());

            //Método:sacarCarro, recibe el numero de carros a sacar del estacionamiento.
            System.out.println("Escribe el numero de carros a sacar del estacionamiento: ");
            carroOut = consola.nextInt();
            centro.getEstacionamiento().sacarCarro(carroOut);
            System.out.println("Carros en el estacionamiento:" + centro.getEstacionamiento().getNumCarros());

            System.out.println("Estacionamiento lleno = " + centro.getEstacionamiento().getEstacionamientoLleno());
            System.out.println("Estacionamiento vacio = " + centro.getEstacionamiento().getEstacionamientoVacio());

            //Tienda Departamental
            System.out.println("TIENDA DEPARTAMENTAL");
            //Metodo ventas, recibe la cantidad de producto comprada y su precio para calcular el total de dinero obtenido por ventas en la tienda 
            System.out.println("Ingresa la cantidad de productos comprados");
            cantidadProductos = consola.nextInt();
            System.out.println("Ingresa el precio de los productos");
            precioProducto = consola.nextFloat();
            System.out.println("Ventas de la tienda  = " + centro.getTienda().ventas(precioProducto, cantidadProductos));

            //Restaurante
            System.out.println("RESTAURANTE");

            System.out.println("Comensales = " + centro.getRestaurante().getNumComensales());
            //Agrega un comensal
            restaurant.agregarComensal();
            System.out.println("Comensales = " + centro.getRestaurante().getNumComensales());
            System.out.println("Ingresa El numero de platillos ordenados");
            int cantidad = consola.nextInt();
            System.out.println("Ingresa el precio del platillo");
            float precio = consola.nextFloat();
            //metodo cuenta, recibe el precio del platillo, la cantidad, y el nombre del platillo para calcular el precio a pagar por los alimentos
            //pedidos por cada comensal.
            System.out.println("Cuenta del restaurante = " + centro.getRestaurante().cuenta("Enchiladas suizas", precio, cantidad));

            //Imprime los datos del Centro Comercial
            centro.imprimir();

        } catch (Exception e) {
            System.out.println("Hay un error");
        }
    }
}
