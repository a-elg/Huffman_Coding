/* 

CentroComercial
Descripción: Permite el acceso a los comercios: Restaurante, TiendaDepartamental, Estacionamiento.

Fecha:24-Nov-2020
Versión: 1|
@author López Hernández Lissete
@author Perez Priego Mario Daniel
 */
package Practica;

public class CentroComercial {

    private String domicilio;
    private double superficie;
    private String nombre;
    private Restaurante restaurante;
    private TiendaDepartamental tienda;
    private Estacionamiento estacionamiento;

    //Constructor CentroComercial: Recibe como parametros el domicilio del centro comercial, su supeficie, su nombre; tambien los objetos de la clase restaurante, tienda departamental y del estacionamiento. 
    //En el caso de Restaurante, recibe el objeto ya creado mientras que, para tienda departamental y el estacionamiento reciben el objeto en null, para que en este constructor sean creados
    public CentroComercial(String domicilio, double superficie, String nombre, Restaurante restaurante, TiendaDepartamental tienda, Estacionamiento estacionamiento) {
        this.domicilio = domicilio;
        this.superficie = superficie;
        this.nombre = nombre;
        this.restaurante = restaurante;
        this.tienda  = new TiendaDepartamental("Soriana", "crema");
        this.estacionamiento = new Estacionamiento();
    }

    //Constructor vacio
    public CentroComercial() {
    }

    
    //Metodos get and set: obtienen y establecen los valores para cada atributo
    public String getDomicilio() {
        return domicilio;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public double getSuperficie() {
        return superficie;
    }

    public void setSuperficie(double metros2) {
        this.superficie = superficie;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Restaurante getRestaurante() {
        return restaurante;
    }

    public TiendaDepartamental getTienda() {
        return tienda;
    }

    public Estacionamiento getEstacionamiento() {
        return estacionamiento;
    }

    //Metodo imprimir: no recibe parametros. Imprime los atributos nombre y domicilio del Centro comercial
    public void imprimir() {
        System.out.println("El centro comercial " + nombre + " de domicilio " + domicilio + " Agradece su visita wapo(a)");
    }

}
