/* 

Estacionamiento
Descripción: Da el acceso al numero de carros maximo permitido por el espacio diponible y tambien se encarga de la salida de los mismos.

Fecha:24-Nov-2020
Versión: 1|
@author López Hernández Lissete
@author Perez Priego Mario Daniel
 */
package Practica;

public class Estacionamiento {

    private int numCarros; //Numero de carros en el estacionamiento
    private double superficie; //Superficie en metros cuadrados del estacionamiento
    private int maxCarros; //Maximo numero de carros permitidos en el estacionamiento
    private boolean estacionamientoLleno; //Determina si el estacionamiento está lleno
    private boolean estacionamientoVacio; //Determina si el estacionamiento esta vacio

    public Estacionamiento() {
        superficie = 100;
        maxCarros = 10;
    } //Constructor vacio

    // El método cuenta el numero de carros a ingresar y compara con el numero maximo de carros que puede albergar el estacionamiento, en caso de que el estacionamiento este lleno, no dejara ingresar al carro. Recibe el numero de carros a ingresar, y no devuelve valores.
    public void ingresarCarro(int numCar) {
       
        for (int i = 0; i < numCar; i++) {
            if ((numCarros + 1) <= maxCarros) {
                numCarros++;
            }
        }

        if (numCarros == maxCarros) {
            estacionamientoLleno = true;
            estacionamientoVacio = false;
        }

    }

    // El metodo sacarCarro  recibe el numero de carros que desean sacarse del estacionamiento, no devuelve valores. El método valida si en el estacionamiento se encuentra el numero de carros indicados, de otra forma, no saca ninguno.
    public void sacarCarro(int numCar) {
        if (numCarros - numCar >= 0) {
            numCarros -= numCar;
        }

        if (numCarros < maxCarros) {
            estacionamientoVacio = false;
            estacionamientoLleno = false;
        }
        if (numCarros == 0) {
            estacionamientoVacio = true;
            estacionamientoLleno = false;

        }
    }
// Metodos get: retornan los valores de los atributos de la clase
    //NumCarros, EstacionamientoVació, EstacionamientoLleno
    public int getNumCarros() {
        return numCarros;
    }

    public boolean getEstacionamientoVacio() {
        return estacionamientoVacio;
    }

    public boolean getEstacionamientoLleno() {
        return estacionamientoLleno;
    }
}
