/* 

Restaurante
Descripción: agrega comensales (de uno en uno), calcula la cuenta a pagar,  y obtiene el numero de comensales en el restaurante. 


Fecha:24-Nov-2020
Versión: 1|
@author López Hernández Lissete
@author Perez Priego Mario Daniel
 */
package Practica;


public class Restaurante {

    private String nombre;
    private int numComensales;
    private int maxNumComensales;
    public String platillo;
    public float precioPlatillo;
    private int cantidadPlatillo;
    
//Constructor: recibe el nombre del restaurante y el nombre de un platillo.
    public Restaurante(String nombre, String platillo) {
        this.nombre = nombre;
        this.platillo = platillo;
    }

    //Metodo agregarComensal, permite el acceso de comensales uno a uno. 
    //No recibe parametros, regresa true si el comensal ingreso al restaurante, false en caso contrario.
    public boolean agregarComensal() {

        if (maxNumComensales >= numComensales) {
            numComensales++;
            return true;
        } else {
            return false;
        }
    }

    //Metodo cuenta: calcula el monto a pagar por los platillos consumidos en el restaurante. 
    //Recibe: el precio del platillo, la cantidad de platillos ordenados y el nombre del platillo. 
    //Retorna el precio a pagar en un tipo de dato float.
    public float cuenta(String platillo, float precioPlatillo, int cantidadPlatillo) {
        this.precioPlatillo = precioPlatillo;
        this.cantidadPlatillo = cantidadPlatillo;

        return precioPlatillo * cantidadPlatillo;
    }

    //Metodo get que obtiene el numero de comensales en el restaurante.
    public int getNumComensales() {
        return numComensales;
    }

}
