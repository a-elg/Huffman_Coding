/* 
Hola mundo en Java
Descripción: El programa imprime una cadena de caracteres
Fecha:16-Oct-2020
Versión: 1
@author López Hernández Lissete
@author Perez Priego Mario Daniel
 */
package HolaMundo;
/*
    Metodo principal
    Imprime la cadena
    Errores: cuando se ingresa un dato diferente a cadena (String)
 */
public class HolaMundo {
    public static void main(String[] args) {
        //Guarda el mensaje ingresado
        String mensaje = "Hola!!! :3";
        //Imprime el mensaje
        System.out.println(mensaje);
    }
}


