/* 
Maximo, minimo y suma de 10 numeros
Descripción: El programa calcula la suma de 10 numeros elegidos e ingresados por el usuario, también identificalos números menor y mayor
Fecha:16-Oct-2020
Versión: 1
@author López Hernández Lissete
@author Perez Priego Mario Daniel
 */
package MayorMenorSuma;

import java.util.Scanner;

public class MinMax {

    /*
        Metodo principal
        realiza los diferentes pasos del algoritmo: calcular maximo y minimo, sumar e imprimir el resultado
        Errores: al ingresar caracteres no numericos y que no sean enteros
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in);
        int suma = 0, min = 0, max = 0;
//Arreglo en el que se guardarán los numeros ingresados por el usuario
        int numeros[] = new int[10];
//Solicita los numeros ingresados 
        for (int i = 0; i < 10; i++) {
            System.out.print("Inserte numero entero:");
            numeros[i] = leer.nextInt();
        }
//Suma los 10 numeros ingresados       
        for (int i = 0; i < 10; i++) {
            suma = suma + numeros[i];
        }
//Obtiene el numero minimo 
        min = numeros[0];
        for (int i = 1; i < 10; i++) {
            if (numeros[i] < min) {
                min = numeros[i];
            }
        }
//Obtiene el numero mayor 
        max = numeros[0];
        for (int i = 1; i < 10; i++) {
            if (numeros[i] > max) {
                max = numeros[i];
            }
        }

        //Muestra los resultados 
        System.out.println("Suma total = " + suma);
        System.out.println("min = " + min);
        System.out.println("max = " + max);
    }
}
